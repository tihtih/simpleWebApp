let map;
var count=0;
var marker=[];
var result = document.getElementById("result")

function initMap() {
    var location = {lat: 35.780837606382626, lng:-5.8120175536910805};
    map = new google.maps.Map(document.getElementById("map"), {
    center: location,
    zoom: 20,
  });
 

map.addListener("click",(mapsMouseEvent)=>{
    if(count<4){
        marker[count] = new google.maps.Marker({
    
            position:mapsMouseEvent.latLng,
            map: map,
            icon:"https://img.icons8.com/2x/marker.png"
      
        });
        
        
        if(count==0){
           document.getElementById('departA').value=mapsMouseEvent.latLng.toString().slice(1,-1); 
        }
        if(count==1){
            document.getElementById('departB').value=mapsMouseEvent.latLng.toString().slice(1,-1);
        }
        if(count==2){
            document.getElementById('departC').value=mapsMouseEvent.latLng.toString().slice(1,-1);
        }
        if(count==3){
            document.getElementById('arriverD').value=mapsMouseEvent.latLng.toString().slice(1,-1);
        }
        
        
        count=count+1;
    }else{
        return;
    }

})
/*
const detailPopup1 = new google.maps.InfoWindow({
    content:'<h2>point 1</h2>'
});

marker[0].addListener("mouseover", ()=>{
    detailPopup1.open(map,marker[0]);
    
});
*/

}
function setMapOnAll(map) {
    for (let i = 0; i < 4; i++) {
      marker[i].setMap(map);
    }
  }

function clearMarkers() {
    setMapOnAll(null);
  }
function deleteMarkers() {
    clearMarkers();
    marker = [];
    count=0;

        document.getElementById('departA').value="";
        document.getElementById('departB').value="";
        document.getElementById('departC').value="";
        document.getElementById('arriverD').value="";

  }


//var gps1 = new google.maps.LatLng( 35.780837606382626, -5.8120175536910805);
//var gps2 = new google.maps.LatLng( 35.7801699695716, -5.809937862172625);


//var distance = google.maps.geometry.spherical.computeDistanceBetween(gps1, gps2)
//console.log(distance/1000); // Distance in Kms
